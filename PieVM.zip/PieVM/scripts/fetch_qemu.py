#!/usr/bin/env python3
"""
Experimental: take QEMU (aarch64, Android/bionic) from the Termux package repository and make it
usable as the app's built-in engine.

  usage: fetch_qemu.py <jniLibs/arm64-v8a dir> <assets/qemu-share dir>

What it does:
  1. Resolves qemu-system-x86-64-headless and its dependencies from the Termux apt repo.
  2. Extracts them and follows DT_NEEDED from the qemu binary to find the libraries it really needs.
  3. Uses patchelf so everything loads from the app's native library dir:
       - qemu binary      -> libqemu.so
       - libfoo.so.1      -> libfoo.so.1.so   (Android only packages lib*.so files)
       - RPATH            -> $ORIGIN
  4. Copies QEMU's firmware files (BIOS, VGA ROMs) for use with -L.

Nothing is written to the output folders unless every step succeeds.
Requires: patchelf, dpkg-deb (both available on GitHub's ubuntu runners after apt install).
"""
import gzip
import lzma
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

REPO = "https://packages.termux.dev/apt/termux-main/"
ARCH = "aarch64"
ROOT_PKG = "qemu-system-x86-64-headless"
MAX_SHARE_FILE = 10 * 1024 * 1024


def fetch(url, tries=4):
    last = None
    for i in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=60) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * (i + 1))
    raise RuntimeError(f"download failed: {url}: {last}")


def load_index():
    base = f"{REPO}dists/stable/main/binary-{ARCH}/Packages"
    for suffix, opener in (("", lambda b: b), (".gz", gzip.decompress), (".xz", lzma.decompress)):
        try:
            data = opener(fetch(base + suffix, tries=2))
            return data.decode("utf-8", "replace")
        except Exception as e:  # noqa: BLE001
            print(f"index {base + suffix}: {e}")
    raise RuntimeError("could not load the Termux package index")


def parse_index(text):
    pkgs = {}
    for block in text.split("\n\n"):
        fields = {}
        key = None
        for line in block.splitlines():
            if line.startswith((" ", "\t")) and key:
                fields[key] += "\n" + line.strip()
            elif ":" in line:
                key, _, val = line.partition(":")
                key = key.strip()
                fields[key] = val.strip()
        name = fields.get("Package")
        if name:
            pkgs[name] = fields
    return pkgs


def dep_names(fields):
    out = []
    for field in ("Pre-Depends", "Depends"):
        for part in fields.get(field, "").split(","):
            part = part.strip()
            if not part:
                continue
            first = part.split("|")[0].strip()
            name = first.split("(")[0].strip().split(" ")[0]
            if name:
                out.append(name)
    return out


def resolve(pkgs, root):
    if root not in pkgs:
        similar = sorted(n for n in pkgs if "qemu" in n)
        raise RuntimeError(f"package {root} not found. Similar packages: {similar}")
    order, seen, stack = [], set(), [root]
    while stack:
        n = stack.pop()
        if n in seen:
            continue
        seen.add(n)
        if n not in pkgs:
            print(f"  (skipping unknown dependency {n})")
            continue
        order.append(n)
        stack.extend(dep_names(pkgs[n]))
    return order


def run(cmd):
    subprocess.check_call(cmd)


def needed(path):
    out = subprocess.check_output(["patchelf", "--print-needed", path], text=True)
    return out.split()


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    out_libs, out_share = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])

    print("Loading Termux package index…")
    pkgs = parse_index(load_index())
    order = resolve(pkgs, ROOT_PKG)
    print(f"{len(order)} packages: {', '.join(order)}")

    work = tempfile.mkdtemp(prefix="qemu-fetch-")
    root = os.path.join(work, "root")
    os.makedirs(root)
    for name in order:
        fname = pkgs[name]["Filename"]
        deb = os.path.join(work, os.path.basename(fname))
        print(f"  downloading {name}")
        with open(deb, "wb") as f:
            f.write(fetch(REPO + fname))
        run(["dpkg-deb", "-x", deb, root])
        os.remove(deb)

    prefix = os.path.join(root, "data", "data", "com.termux", "files", "usr")
    binary = os.path.join(prefix, "bin", "qemu-system-x86_64")
    libdir = os.path.join(prefix, "lib")
    if not os.path.exists(binary):
        print("qemu-system-x86_64 not found. bin contents:", os.listdir(os.path.join(prefix, "bin")))
        return 1

    # Which libraries does QEMU really need? (follow DT_NEEDED from the binary)
    mapping = {}  # original soname -> new file name
    sources = {}  # new file name -> real file
    seen = set()
    queue = [binary]
    while queue:
        f = queue.pop()
        for n in needed(f):
            if n in seen:
                continue
            seen.add(n)
            cand = os.path.join(libdir, n)
            if os.path.exists(cand):
                new = n if n.endswith(".so") else n + ".so"
                mapping[n] = new
                sources[new] = os.path.realpath(cand)
                queue.append(cand)
            # otherwise it is an Android system library (libc.so, libm.so, ...): leave as is
    print(f"{len(sources)} libraries bundled; system libraries left alone")

    stage = os.path.join(work, "stage")
    os.makedirs(stage)

    def patch(path, soname=None):
        cmd = ["patchelf", "--set-rpath", "$ORIGIN"]
        if soname:
            cmd += ["--set-soname", soname]
        for old, new in mapping.items():
            cmd += ["--replace-needed", old, new]
        cmd.append(path)
        run(cmd)

    qemu_out = os.path.join(stage, "libqemu.so")
    shutil.copy2(binary, qemu_out)
    os.chmod(qemu_out, 0o755)
    patch(qemu_out)
    for new, src in sources.items():
        dst = os.path.join(stage, new)
        shutil.copy2(src, dst)
        os.chmod(dst, 0o755)
        patch(dst, soname=new)

    share_stage = os.path.join(work, "share")
    os.makedirs(share_stage)
    share_src = os.path.join(prefix, "share", "qemu")
    copied = 0
    if os.path.isdir(share_src):
        for n in os.listdir(share_src):
            p = os.path.join(share_src, n)
            if os.path.isfile(p) and os.path.getsize(p) <= MAX_SHARE_FILE:
                shutil.copy2(p, os.path.join(share_stage, n))
                copied += 1
    print(f"{copied} firmware files")
    if not os.path.exists(os.path.join(share_stage, "bios-256k.bin")):
        print("warning: bios-256k.bin not found in the package; QEMU may not boot")

    # Everything worked: publish into the project
    os.makedirs(out_libs, exist_ok=True)
    os.makedirs(out_share, exist_ok=True)
    for n in os.listdir(stage):
        shutil.copy2(os.path.join(stage, n), os.path.join(out_libs, n))
    for n in os.listdir(share_stage):
        shutil.copy2(os.path.join(share_stage, n), os.path.join(out_share, n))
    print(f"Done: {len(os.listdir(stage))} files -> {out_libs}")
    shutil.rmtree(work, ignore_errors=True)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: {exc}")
        sys.exit(1)
