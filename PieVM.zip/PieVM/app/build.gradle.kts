plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pievm"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.pievm"
        // Host phone: Android 7.0 (API 24) up to Android 15 (API 35)
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            // The bundled QEMU engine is a 32-bit ARM build. With only armeabi-v7a libraries the
            // app runs in 32-bit mode on both 32-bit and 64-bit ARM phones.
            abiFilters += listOf("armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        // Extract .so files to disk so libqemu.so can be executed as a program
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
