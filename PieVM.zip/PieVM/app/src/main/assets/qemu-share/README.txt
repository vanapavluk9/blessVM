BIOS, VGA ROM and keymaps are added here automatically by the GitHub build
(.github/workflows/build.yml, step "QEMU firmware files"). Nothing to do by hand.
