Put QEMU's firmware/ROM files here before building (they are copied to the app's
private storage on first run and passed to QEMU with -L).

Typical files for qemu-system-x86_64:
  bios-256k.bin   vgabios-stdvga.bin   kvmvapic.bin   linuxboot_dma.bin
  efi-e1000.rom   efi-virtio.rom

Copy them from the "pc-bios" folder of the same QEMU build/version you use for libqemu.so.
