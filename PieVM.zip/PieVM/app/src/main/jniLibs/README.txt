armeabi-v7a/ contains the 32-bit ARM QEMU 5.1 engine (x86_64 guest) and its helper libraries,
taken from the Limbo PC Emulator app (GPLv2, https://github.com/limboemu/limbo).
liblimbo.so is the JNI bridge used by com.max2idea.android.limbo.jni.VMExecutor.
Do not rename these files.
