Place the QEMU engine here, named exactly libqemu.so (it is an executable, the .so name is
required so Android extracts it):

  arm64-v8a/libqemu.so   <- qemu-system-x86_64 built for Android arm64 (most phones)
  x86_64/libqemu.so      <- qemu-system-x86_64 built for Android x86_64 (emulators / Chromebooks)

Any shared libraries the binary needs must also be put in the same folder as lib<name>.so files.
A statically linked build is the easiest. See ../../../../README.md for details.
