package com.max2idea.android.limbo.jni;

/**
 * Bridge to the native QEMU engine (liblimbo.so + libqemu-system-x86_64.so).
 *
 * The package and class name are fixed on purpose: the prebuilt native library looks the native
 * methods and the callbacks below up by exactly this name. Do not rename or move this class.
 */
public class VMExecutor {

    static {
        // liblimbo.so pulls in libcompat-limbo, libcompat-musl, libglib-2.0, libpixman-1, libSDL2
        System.loadLibrary("limbo");
    }

    /**
     * Runs QEMU inside this process. Blocks until the virtual machine ends.
     *
     * @param storageDir    app data dir
     * @param baseDir       app data dir
     * @param libPath       directory that contains the QEMU library (nativeLibraryDir)
     * @param libFile       file name of the QEMU library
     * @param sdlScaleHint  unused for VNC, pass 0
     * @param params        QEMU command line, params[0] is the program name
     */
    public native void start(String storageDir, String baseDir, String libPath, String libFile,
                             int sdlScaleHint, String[] params);

    /** restart == 0: shut down, otherwise reset. */
    public native void stop(int restart);

    // ---- callbacks called from native code (names and signatures are fixed) ----

    /** Opens a content:// document and returns a file descriptor. Not used: we only use plain files. */
    public int get_fd(String path) {
        return -1;
    }

    public int close_fd(int fd) {
        return 0;
    }

    public static void onVMResolutionChanged(int width, int height) {
        // The guest screen is read over VNC, nothing to do here.
    }
}
