package com.example.pievm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.system.Os
import android.system.OsConstants
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.max2idea.android.limbo.jni.VMExecutor
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Runs QEMU inside this process. Declared with android:process=":vm" in the manifest, so when the
 * VM ends the whole process is killed and the next start gets a clean QEMU.
 */
class VmService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            killProcess()
            return START_NOT_STICKY
        }

        createChannel()
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VmService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, getString(R.string.notif_stop), stop)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notification, type)

        val json = intent?.getStringExtra(VmManager.EXTRA_CFG)
        if (json == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (worker == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PieVM:running").apply {
                setReferenceCounted(false)
                acquire()
            }
            val cfg = VmConfig.fromJson(JSONObject(json))
            worker = Thread({ runVm(cfg) }, "qemu").also { it.start() }
        }
        return START_NOT_STICKY
    }

    private fun runVm(cfg: VmConfig) {
        val dir = File(filesDir, "vms/${cfg.id}").apply { mkdirs() }
        val marker = File(dir, "running.pid")
        val log = File(dir, "vm.log")
        try {
            marker.writeText(android.os.Process.myPid().toString())
            redirectOutput(log)
            val share = prepareShare()
            val args = buildArgs(cfg, dir, share)
            log.appendText("Starting: ${args.joinToString(" ")}\n")

            log.appendText("Loading native bridge...\n")
            val executor = VMExecutor()
            log.appendText("Native bridge loaded, starting QEMU...\n")
            // Blocks until the virtual machine ends
            executor.start(
                filesDir.absolutePath,
                filesDir.absolutePath,
                applicationInfo.nativeLibraryDir,
                VmManager.LIB_NAME,
                0,
                args.toTypedArray(),
            )
            log.appendText("QEMU finished.\n")
        } catch (t: Throwable) {
            try {
                log.appendText("ERROR: $t\n")
            } catch (_: IOException) {
            }
        } finally {
            marker.delete()
            killProcess()
        }
    }

    private fun buildArgs(cfg: VmConfig, dir: File, share: File): List<String> {
        val disk = File(dir, "disk.img")
        val iso = File(dir, "install.iso")
        val bootFromIso = !cfg.installed && cfg.hasIso && iso.exists()

        val a = mutableListOf(
            "qemu-system-x86_64",
            "-L", share.absolutePath,
            "-machine", "pc",
            "-cpu", "max",
            "-accel", "tcg",
            "-m", cfg.ramMb.toString(),
            "-smp", cfg.cpus.toString(),
            "-drive", "file=${disk.absolutePath},format=raw,if=virtio",
        )
        if (bootFromIso) {
            a += listOf("-cdrom", iso.absolutePath, "-boot", "d")
        } else {
            a += listOf("-boot", "c")
        }
        a += listOf(
            "-vga", "std",
            "-usb", "-device", "usb-tablet",
            "-netdev", "user,id=n0,hostfwd=tcp:127.0.0.1:${cfg.adbPort}-:5555",
            "-device", "e1000,netdev=n0,romfile=",
            "-vnc", "127.0.0.1:${cfg.display}",
            "-monitor", "none",
            "-serial", "none",
        )
        return a
    }

    /** Send QEMU's stdout/stderr to vm.log so errors can be shown in the app. */
    private fun redirectOutput(log: File) {
        try {
            val fos = FileOutputStream(log, true)
            Os.dup2(fos.fd, OsConstants.STDOUT_FILENO)
            Os.dup2(fos.fd, OsConstants.STDERR_FILENO)
        } catch (_: Exception) {
        }
    }

    /** Copies BIOS, VGA ROM and keymaps from assets/qemu-share to a folder QEMU can read. */
    private fun prepareShare(): File {
        val dir = File(filesDir, "qemu-share")
        val marker = File(dir, ".copied-v2")
        if (marker.exists()) return dir
        dir.deleteRecursively()
        dir.mkdirs()
        copyAssets("qemu-share", dir)
        marker.writeText("ok")
        return dir
    }

    private fun copyAssets(path: String, target: File) {
        val names = assets.list(path) ?: return
        target.mkdirs()
        for (n in names) {
            val child = "$path/$n"
            val sub = assets.list(child)
            if (sub != null && sub.isNotEmpty()) {
                copyAssets(child, File(target, n))
            } else {
                try {
                    assets.open(child).use { input ->
                        File(target, n).outputStream().use { input.copyTo(it) }
                    }
                } catch (_: IOException) {
                }
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Virtual machines", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun killProcess() {
        wakeLock?.let { if (it.isHeld) it.release() }
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.pievm.STOP"
        private const val CHANNEL = "vm_running"
        private const val NOTIF_ID = 1
    }
}
