package com.example.pievm

import org.json.JSONObject

/** One virtual machine definition. */
data class VmConfig(
    val id: String,
    var name: String,
    var ramMb: Int,
    var cpus: Int,
    var diskGb: Int,
    var hasIso: Boolean,
    var installed: Boolean,
    val display: Int,
) {
    /** VNC port QEMU listens on (127.0.0.1 only). */
    val vncPort: Int get() = 5900 + display

    /** Host port forwarded to the guest's adb port (5555). */
    val adbPort: Int get() = 15555 + display

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("ramMb", ramMb)
        .put("cpus", cpus)
        .put("diskGb", diskGb)
        .put("hasIso", hasIso)
        .put("installed", installed)
        .put("display", display)

    companion object {
        fun fromJson(o: JSONObject) = VmConfig(
            id = o.getString("id"),
            name = o.getString("name"),
            ramMb = o.getInt("ramMb"),
            cpus = o.getInt("cpus"),
            diskGb = o.getInt("diskGb"),
            hasIso = o.optBoolean("hasIso", false),
            installed = o.optBoolean("installed", false),
            display = o.getInt("display"),
        )
    }
}
