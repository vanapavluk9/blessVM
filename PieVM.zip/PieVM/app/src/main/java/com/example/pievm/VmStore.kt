package com.example.pievm

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.util.UUID

/** Persists VM definitions and owns each VM's folder (disk image, ISO). */
class VmStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("vms", Context.MODE_PRIVATE)

    fun all(): MutableList<VmConfig> {
        val raw = prefs.getString("list", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<VmConfig>()
        for (i in 0 until arr.length()) {
            try {
                out += VmConfig.fromJson(arr.getJSONObject(i))
            } catch (_: Exception) {
                // skip corrupt entries
            }
        }
        return out
    }

    fun get(id: String): VmConfig? = all().firstOrNull { it.id == id }

    private fun write(list: List<VmConfig>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun create(name: String, ramMb: Int, cpus: Int, diskGb: Int, hasIso: Boolean): VmConfig {
        val display = prefs.getInt("next_display", 1)
        prefs.edit().putInt("next_display", display + 1).apply()
        val cfg = VmConfig(
            id = UUID.randomUUID().toString().take(8),
            name = name,
            ramMb = ramMb,
            cpus = cpus,
            diskGb = diskGb,
            hasIso = hasIso,
            installed = false,
            display = display,
        )
        val list = all()
        list += cfg
        write(list)
        dir(cfg.id)
        return cfg
    }

    fun update(cfg: VmConfig) {
        val list = all()
        val i = list.indexOfFirst { it.id == cfg.id }
        if (i >= 0) {
            list[i] = cfg
            write(list)
        }
    }

    fun delete(id: String) {
        VmManager.stop(ctx, id)
        write(all().filter { it.id != id })
        dir(id).deleteRecursively()
    }

    fun dir(id: String): File = File(ctx.filesDir, "vms/$id").apply { mkdirs() }
    fun diskFile(id: String) = File(dir(id), "disk.img")
    fun isoFile(id: String) = File(dir(id), "install.iso")
}
