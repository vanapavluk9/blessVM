package com.example.pievm

import android.graphics.Bitmap
import android.graphics.Color
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/**
 * Minimal RFB (VNC) client for QEMU's built-in VNC server: no authentication, Raw encoding,
 * 32-bit pixels, plus the DesktopSize pseudo-encoding so the guest can change resolution.
 */
class VncClient(private val host: String, private val port: Int) {

    interface Listener {
        fun onFrame()
        fun onClosed(reason: String)
    }

    @Volatile
    var listener: Listener? = null

    /** Guards [bitmap] between the network thread (writes) and the UI thread (draws). */
    val lock = Any()

    @Volatile
    var bitmap: Bitmap? = null
        private set

    @Volatile
    var width = 0
        private set

    @Volatile
    var height = 0
        private set

    private val writeLock = Any()
    private val sender = Executors.newSingleThreadExecutor()

    private var socket: Socket? = null
    private var input: DataInputStream? = null
    private var output: OutputStream? = null

    @Volatile
    private var closed = false

    private var rawBuf = ByteArray(0)
    private var pix = IntArray(0)

    /** Connects and performs the RFB handshake. Throws if the server is not ready yet. */
    @Throws(IOException::class)
    fun handshake() {
        val s = Socket()
        socket = s
        s.connect(InetSocketAddress(host, port), 2000)
        s.tcpNoDelay = true
        s.soTimeout = 10000

        val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
        input = inp
        output = BufferedOutputStream(s.getOutputStream())

        val ver = ByteArray(12)
        inp.readFully(ver)
        if (!String(ver, Charsets.US_ASCII).startsWith("RFB ")) throw IOException("Not a VNC server")
        write("RFB 003.008\n".toByteArray(Charsets.US_ASCII))

        val count = inp.readUnsignedByte()
        if (count == 0) {
            val len = inp.readInt()
            val msg = ByteArray(len.coerceIn(0, 4096))
            inp.readFully(msg)
            throw IOException(String(msg))
        }
        val types = ByteArray(count)
        inp.readFully(types)
        if (!types.contains(1.toByte())) throw IOException("VNC server requires a password")
        write(byteArrayOf(1)) // security type: None
        if (inp.readInt() != 0) throw IOException("VNC security handshake failed")

        write(byteArrayOf(1)) // ClientInit: shared
        val w = inp.readUnsignedShort()
        val h = inp.readUnsignedShort()
        skip(16) // server pixel format (we override it below)
        val nameLen = inp.readInt()
        skip(nameLen.toLong())

        // SetPixelFormat: 32 bpp, depth 24, little endian, true colour, R<<16 | G<<8 | B
        val pf = ByteArray(20)
        pf[0] = 0
        pf[4] = 32
        pf[5] = 24
        pf[6] = 0
        pf[7] = 1
        putShort(pf, 8, 255)
        putShort(pf, 10, 255)
        putShort(pf, 12, 255)
        pf[14] = 16
        pf[15] = 8
        pf[16] = 0
        write(pf)

        // SetEncodings: Raw (0) and DesktopSize (-223)
        val enc = ByteArray(4 + 8)
        enc[0] = 2
        putShort(enc, 2, 2)
        putInt(enc, 4, 0)
        putInt(enc, 8, -223)
        write(enc)

        resize(w, h)
        requestUpdate(incremental = false)
        s.soTimeout = 0
    }

    /** Reads server messages until the connection ends. Call on a background thread. */
    fun runLoop() {
        val inp = input ?: return
        var needFull = false
        try {
            while (!closed) {
                when (val type = inp.readUnsignedByte()) {
                    0 -> { // FramebufferUpdate
                        inp.readUnsignedByte()
                        val rects = inp.readUnsignedShort()
                        repeat(rects) {
                            val x = inp.readUnsignedShort()
                            val y = inp.readUnsignedShort()
                            val w = inp.readUnsignedShort()
                            val h = inp.readUnsignedShort()
                            when (val encoding = inp.readInt()) {
                                0 -> readRaw(inp, x, y, w, h)
                                -223 -> {
                                    resize(w, h)
                                    needFull = true
                                }
                                else -> throw IOException("Unsupported VNC encoding $encoding")
                            }
                        }
                        listener?.onFrame()
                        requestUpdate(incremental = !needFull)
                        needFull = false
                    }
                    1 -> { // SetColourMapEntries (unused with true colour)
                        inp.readUnsignedByte()
                        inp.readUnsignedShort()
                        val n = inp.readUnsignedShort()
                        skip(n * 6L)
                    }
                    2 -> Unit // Bell
                    3 -> { // ServerCutText
                        skip(3)
                        val len = inp.readInt()
                        skip(len.toLong())
                    }
                    else -> throw IOException("Unknown VNC message $type")
                }
            }
            listener?.onClosed("closed")
        } catch (e: Exception) {
            if (!closed) listener?.onClosed(e.message ?: "connection lost") else listener?.onClosed("closed")
        }
    }

    fun close() {
        closed = true
        try {
            socket?.close()
        } catch (_: IOException) {
        }
        sender.shutdownNow()
    }

    // ---- input (safe to call from the UI thread) ----

    fun pointer(buttonMask: Int, x: Int, y: Int) {
        val m = ByteArray(6)
        m[0] = 5
        m[1] = buttonMask.toByte()
        putShort(m, 2, x)
        putShort(m, 4, y)
        sendAsync(m)
    }

    fun key(down: Boolean, keysym: Int) {
        val m = ByteArray(8)
        m[0] = 4
        m[1] = if (down) 1 else 0
        putInt(m, 4, keysym)
        sendAsync(m)
    }

    // ---- internals ----

    private fun sendAsync(data: ByteArray) {
        try {
            sender.execute { write(data) }
        } catch (_: Exception) {
            // executor already shut down
        }
    }

    private fun write(data: ByteArray) {
        synchronized(writeLock) {
            try {
                output?.write(data)
                output?.flush()
            } catch (_: IOException) {
            }
        }
    }

    private fun requestUpdate(incremental: Boolean) {
        val m = ByteArray(10)
        m[0] = 3
        m[1] = if (incremental) 1 else 0
        putShort(m, 6, width)
        putShort(m, 8, height)
        write(m)
    }

    private fun resize(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        synchronized(lock) {
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.BLACK)
            bitmap = bmp
            width = w
            height = h
        }
    }

    private fun readRaw(inp: DataInputStream, x: Int, y: Int, w: Int, h: Int) {
        if (w == 0 || h == 0) return
        if (x + w > width || y + h > height) throw IOException("VNC rectangle out of bounds")
        val count = w * h
        val bytes = count * 4
        if (rawBuf.size < bytes) rawBuf = ByteArray(bytes)
        if (pix.size < count) pix = IntArray(count)
        inp.readFully(rawBuf, 0, bytes)

        var j = 0
        for (i in 0 until count) {
            val b = rawBuf[j].toInt() and 0xFF
            val g = rawBuf[j + 1].toInt() and 0xFF
            val r = rawBuf[j + 2].toInt() and 0xFF
            pix[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            j += 4
        }
        synchronized(lock) {
            bitmap?.setPixels(pix, 0, w, x, y, w, h)
        }
    }

    private fun skip(n: Long) {
        val inp = input ?: return
        var left = n
        val tmp = ByteArray(4096)
        while (left > 0) {
            val chunk = minOf(left, tmp.size.toLong()).toInt()
            inp.readFully(tmp, 0, chunk)
            left -= chunk
        }
    }

    private fun putShort(b: ByteArray, off: Int, v: Int) {
        b[off] = (v shr 8).toByte()
        b[off + 1] = v.toByte()
    }

    private fun putInt(b: ByteArray, off: Int, v: Int) {
        b[off] = (v shr 24).toByte()
        b[off + 1] = (v shr 16).toByte()
        b[off + 2] = (v shr 8).toByte()
        b[off + 3] = v.toByte()
    }
}
