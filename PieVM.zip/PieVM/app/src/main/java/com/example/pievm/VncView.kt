package com.example.pievm

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.InputType
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection

/**
 * Draws the guest screen and turns touches / keys into VNC input.
 * One finger = mouse (tap = click, drag = drag). Two-finger tap = right click.
 */
class VncView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    private var client: VncClient? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()
    private var rightClickMode = false

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    fun attach(c: VncClient?) {
        client = c
        postInvalidate()
    }

    fun sendKey(keysym: Int) {
        client?.key(true, keysym)
        client?.key(false, keysym)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val c = client ?: return
        synchronized(c.lock) {
            val bmp = c.bitmap ?: return
            computeDst(bmp.width, bmp.height)
            canvas.drawBitmap(bmp, null, dst, paint)
        }
    }

    private fun computeDst(bw: Int, bh: Int) {
        val scale = minOf(width.toFloat() / bw, height.toFloat() / bh)
        val dw = bw * scale
        val dh = bh * scale
        val left = (width - dw) / 2f
        val top = (height - dh) / 2f
        dst.set(left, top, left + dw, top + dh)
    }

    /** Maps a view coordinate to guest framebuffer pixels. */
    private fun mapX(x: Float, c: VncClient): Int {
        if (dst.width() <= 0f) return 0
        return ((x - dst.left) / dst.width() * c.width).toInt().coerceIn(0, maxOf(c.width - 1, 0))
    }

    private fun mapY(y: Float, c: VncClient): Int {
        if (dst.height() <= 0f) return 0
        return ((y - dst.top) / dst.height() * c.height).toInt().coerceIn(0, maxOf(c.height - 1, 0))
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val c = client ?: return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                rightClickMode = false
                val x = mapX(e.x, c)
                val y = mapY(e.y, c)
                c.pointer(0, x, y) // move first so the press lands on the right spot
                c.pointer(1, x, y)
                requestFocus()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2 && !rightClickMode) {
                    rightClickMode = true
                    val x = mapX(e.getX(0), c)
                    val y = mapY(e.getY(0), c)
                    c.pointer(0, x, y) // release the left button
                    c.pointer(4, x, y) // right click
                    c.pointer(0, x, y)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!rightClickMode) c.pointer(1, mapX(e.x, c), mapY(e.y, c))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!rightClickMode) c.pointer(0, mapX(e.x, c), mapY(e.y, c))
                rightClickMode = false
            }
        }
        return true
    }

    // ---- keyboard ----

    override fun onCheckIsTextEditor() = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or
            EditorInfo.IME_FLAG_NO_EXTRACT_UI or
            EditorInfo.IME_ACTION_NONE
        return object : BaseInputConnection(this, false) {
            override fun commitText(text: CharSequence, newCursorPosition: Int): Boolean {
                typeText(text)
                return true
            }

            override fun setComposingText(text: CharSequence, newCursorPosition: Int): Boolean = true

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                repeat(beforeLength) { sendKey(KEYSYM_BACKSPACE) }
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean {
                val sym = keysymFor(event.keyCode, event)
                if (sym != 0) client?.key(event.action == KeyEvent.ACTION_DOWN, sym)
                return true
            }
        }
    }

    private fun typeText(text: CharSequence) {
        for (ch in text) {
            val sym = when {
                ch == '\n' -> KEYSYM_RETURN
                ch.code < 0x100 -> ch.code
                else -> 0x01000000 + ch.code
            }
            sendKey(sym)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val sym = keysymFor(keyCode, event)
        if (sym == 0) return super.onKeyDown(keyCode, event)
        client?.key(true, sym)
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val sym = keysymFor(keyCode, event)
        if (sym == 0) return super.onKeyUp(keyCode, event)
        client?.key(false, sym)
        return true
    }

    private fun keysymFor(code: Int, ev: KeyEvent?): Int = when (code) {
        KeyEvent.KEYCODE_DEL -> KEYSYM_BACKSPACE
        KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> KEYSYM_RETURN
        KeyEvent.KEYCODE_TAB -> 0xFF09
        KeyEvent.KEYCODE_ESCAPE -> 0xFF1B
        KeyEvent.KEYCODE_FORWARD_DEL -> 0xFFFF
        KeyEvent.KEYCODE_DPAD_LEFT -> 0xFF51
        KeyEvent.KEYCODE_DPAD_UP -> 0xFF52
        KeyEvent.KEYCODE_DPAD_RIGHT -> 0xFF53
        KeyEvent.KEYCODE_DPAD_DOWN -> 0xFF54
        KeyEvent.KEYCODE_MOVE_HOME -> 0xFF50
        KeyEvent.KEYCODE_MOVE_END -> 0xFF57
        KeyEvent.KEYCODE_PAGE_UP -> 0xFF55
        KeyEvent.KEYCODE_PAGE_DOWN -> 0xFF56
        KeyEvent.KEYCODE_SPACE -> 0x20
        KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME,
        KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_POWER -> 0
        else -> {
            val u = ev?.unicodeChar ?: 0
            if (u in 0x20..0xFF) u else 0
        }
    }

    companion object {
        const val KEYSYM_BACKSPACE = 0xFF08
        const val KEYSYM_RETURN = 0xFF0D
        const val KEYSYM_ESCAPE = 0xFF1B
        const val KEYSYM_SUPER_L = 0xFFEB // Android-x86 treats the Windows/Super key as Home
    }
}
