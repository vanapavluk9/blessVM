package com.example.pievm

import android.content.Context
import android.content.Intent
import android.os.Process
import androidx.core.content.ContextCompat
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/**
 * UI-process side of the built-in engine. QEMU itself runs inside [VmService], which lives in its
 * own process (":vm") because QEMU cannot be started twice in one process. The two processes only
 * talk through files (running.pid, vm.log) and the VNC socket.
 */
object VmManager {
    const val LIB_NAME = "libqemu-system-x86_64.so"
    const val EXTRA_CFG = "cfg"

    fun hasEngine(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, LIB_NAME).exists()

    private fun vmDir(ctx: Context, id: String) = File(ctx.filesDir, "vms/$id")
    private fun marker(ctx: Context, id: String) = File(vmDir(ctx, id), "running.pid")
    fun logFile(ctx: Context, id: String) = File(vmDir(ctx, id), "vm.log")

    private fun pidOf(ctx: Context, id: String): Int? {
        val f = marker(ctx, id)
        if (!f.exists()) return null
        val pid = try {
            f.readText().trim().toIntOrNull()
        } catch (_: IOException) {
            null
        } ?: return null
        // Make sure the pid really is our ":vm" process (pids can be reused after a reboot)
        val name = try {
            File("/proc/$pid/cmdline").readText().trim('\u0000', ' ', '\n')
        } catch (_: IOException) {
            ""
        }
        if (name != "${ctx.packageName}:vm") {
            f.delete()
            return null
        }
        return pid
    }

    fun isRunning(ctx: Context, id: String) = pidOf(ctx, id) != null

    /** Last part of QEMU's output, for error messages. */
    fun tail(ctx: Context, id: String, max: Int = 1500): String {
        return try {
            val t = logFile(ctx, id).readText()
            if (t.length > max) t.substring(t.length - max) else t
        } catch (_: IOException) {
            ""
        }
    }

    @Throws(IOException::class)
    fun start(ctx: Context, cfg: VmConfig, store: VmStore) {
        if (isRunning(ctx, cfg.id)) return

        if (!hasEngine(ctx)) {
            throw IOException(
                "QEMU engine not found ($LIB_NAME).\n\n" +
                    "The built-in engine is not part of this build. Use the Termux mode instead, " +
                    "or see README.md."
            )
        }

        val disk = store.diskFile(cfg.id)
        if (!disk.exists()) {
            // Sparse raw disk: takes almost no real space until the guest writes to it
            RandomAccessFile(disk, "rw").use { it.setLength(cfg.diskGb * 1024L * 1024L * 1024L) }
        }
        if (!cfg.installed && cfg.hasIso && !store.isoFile(cfg.id).exists()) {
            throw IOException("The installation ISO is missing. Delete this VM and create it again.")
        }

        logFile(ctx, cfg.id).delete()
        val intent = Intent(ctx, VmService::class.java).putExtra(EXTRA_CFG, cfg.toJson().toString())
        ContextCompat.startForegroundService(ctx, intent)
    }

    /** Pulls the plug: killing the ":vm" process ends QEMU immediately. */
    fun stop(ctx: Context, id: String) {
        val pid = pidOf(ctx, id) ?: return
        Process.killProcess(pid)
        marker(ctx, id).delete()
    }
}
