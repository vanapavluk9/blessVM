package com.example.pievm

import android.content.Context
import android.os.Build
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap

/**
 * Launches and tracks QEMU processes.
 *
 * The QEMU binary is shipped as app/src/main/jniLibs/<abi>/libqemu.so. Android extracts it to the
 * app's native library directory, which is the one place an app may execute files from on every
 * Android version from 7 to 15.
 */
object VmManager {
    private val procs = ConcurrentHashMap<String, Process>()
    private val logs = ConcurrentHashMap<String, StringBuilder>()

    /** Called (on a background thread) whenever a VM process exits. */
    @Volatile
    var onChange: (() -> Unit)? = null

    fun qemuBinary(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")

    fun isRunning(id: String) = procs.containsKey(id)
    fun runningCount() = procs.size

    fun tail(id: String, max: Int = 1500): String {
        val sb = logs[id] ?: return ""
        synchronized(sb) {
            return if (sb.length > max) sb.substring(sb.length - max) else sb.toString()
        }
    }

    @Synchronized
    @Throws(IOException::class)
    fun start(ctx: Context, cfg: VmConfig, store: VmStore) {
        if (isRunning(cfg.id)) return

        val bin = qemuBinary(ctx)
        if (!bin.exists()) {
            throw IOException(
                "QEMU engine not found (libqemu.so).\n\n" +
                    "Add a QEMU build for your phone's CPU to app/src/main/jniLibs/ and rebuild. See README.md."
            )
        }

        val share = prepareShare(ctx)

        val disk = store.diskFile(cfg.id)
        if (!disk.exists()) {
            // Sparse raw disk: takes almost no real space until the guest writes to it
            RandomAccessFile(disk, "rw").use { it.setLength(cfg.diskGb * 1024L * 1024L * 1024L) }
        }

        val iso = store.isoFile(cfg.id)
        val bootFromIso = !cfg.installed && cfg.hasIso && iso.exists()

        val args = mutableListOf(
            bin.absolutePath,
            "-L", share.absolutePath,
            "-machine", "pc",
            "-cpu", "max",
            "-accel", "tcg,thread=multi",
            "-m", cfg.ramMb.toString(),
            "-smp", cfg.cpus.toString(),
            "-drive", "file=${disk.absolutePath},format=raw,if=virtio",
        )
        if (bootFromIso) {
            args += listOf("-cdrom", iso.absolutePath, "-boot", "d")
        } else {
            args += listOf("-boot", "c")
        }
        args += listOf(
            "-vga", "std",
            "-usb", "-device", "usb-tablet",
            "-netdev", "user,id=n0,hostfwd=tcp:127.0.0.1:${cfg.adbPort}-:5555",
            "-device", "e1000,netdev=n0",
            "-display", "none",
            "-vnc", "127.0.0.1:${cfg.display}",
            "-monitor", "none",
            "-serial", "none",
        )

        val pb = ProcessBuilder(args)
        pb.directory(store.dir(cfg.id))
        pb.redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = ctx.applicationInfo.nativeLibraryDir
        pb.environment()["TMPDIR"] = ctx.cacheDir.absolutePath

        val log = StringBuilder()
        logs[cfg.id] = log
        val process = pb.start()
        procs[cfg.id] = process

        // Drain QEMU's output so it never blocks, and keep the last part for error messages
        Thread {
            try {
                BufferedReader(InputStreamReader(process.inputStream)).use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        synchronized(log) {
                            log.append(line).append('\n')
                            if (log.length > 20000) log.delete(0, log.length - 15000)
                        }
                    }
                }
            } catch (_: IOException) {
            }
        }.start()

        // Clean up when QEMU exits
        Thread {
            try {
                val code = process.waitFor()
                synchronized(log) { log.append("QEMU exited with code $code\n") }
            } catch (_: InterruptedException) {
            }
            procs.remove(cfg.id)
            onChange?.invoke()
        }.start()
    }

    fun stop(id: String) {
        val p = procs[id] ?: return
        p.destroy()
        if (Build.VERSION.SDK_INT >= 26) {
            Thread {
                try {
                    Thread.sleep(3000)
                } catch (_: InterruptedException) {
                }
                if (procs[id] === p) p.destroyForcibly()
            }.start()
        }
    }

    fun stopAll() {
        procs.keys.toList().forEach { stop(it) }
    }

    /** Copies optional BIOS/ROM files from assets/qemu-share to a folder QEMU can read. */
    private fun prepareShare(ctx: Context): File {
        val dir = File(ctx.filesDir, "qemu-share")
        val marker = File(dir, ".copied-v1")
        if (marker.exists()) return dir
        dir.mkdirs()
        val names = ctx.assets.list("qemu-share") ?: emptyArray()
        for (name in names) {
            ctx.assets.open("qemu-share/$name").use { input ->
                File(dir, name).outputStream().use { input.copyTo(it) }
            }
        }
        marker.writeText("ok")
        return dir
    }
}
