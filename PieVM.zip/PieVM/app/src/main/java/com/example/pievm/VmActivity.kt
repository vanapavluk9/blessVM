package com.example.pievm

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Shows one VM screen over VNC.
 *
 * Two modes:
 *  - built-in: starts the bundled QEMU (libqemu.so) for a VM from the list;
 *  - external: only connects to a QEMU that is already running elsewhere on the phone
 *    (for example in Termux) on 127.0.0.1:EXTRA_PORT.
 */
class VmActivity : AppCompatActivity(), VncClient.Listener {

    private lateinit var store: VmStore
    private lateinit var view: VncView
    private lateinit var status: TextView

    /** null in external (Termux) mode. */
    private var cfg: VmConfig? = null
    private var port = 0

    @Volatile
    private var client: VncClient? = null

    @Volatile
    private var leaving = false
    private var worker: Thread? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vm)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        store = VmStore(this)

        val extPort = intent.getIntExtra(EXTRA_PORT, 0)
        if (extPort > 0) {
            port = extPort
        } else {
            val found = intent.getStringExtra(EXTRA_ID)?.let { store.get(it) }
            if (found == null) {
                finish()
                return
            }
            cfg = found
            port = found.vncPort
        }

        view = findViewById(R.id.vnc)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.btnBack).setOnClickListener { view.sendKey(VncView.KEYSYM_ESCAPE) }
        findViewById<Button>(R.id.btnHome).setOnClickListener { view.sendKey(VncView.KEYSYM_SUPER_L) }
        findViewById<Button>(R.id.btnKeys).setOnClickListener {
            view.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        }
        val stopBtn = findViewById<Button>(R.id.btnStop)
        if (cfg == null) {
            stopBtn.text = "Disconnect"
            stopBtn.setOnClickListener { finish() }
        } else {
            stopBtn.setOnClickListener { confirmPowerOff() }
        }

        if (cfg == null) startExternal() else startBuiltIn()
    }

    private fun startExternal() {
        setStatus("Connecting to QEMU on 127.0.0.1:$port …\n\nStart QEMU in Termux first (see the guide on the main screen).")
        worker = Thread { connectAndRun() }.also { it.start() }
    }

    private fun startBuiltIn() {
        val c = cfg ?: return
        setStatus(getString(R.string.starting))
        ContextCompat.startForegroundService(this, Intent(this, VmService::class.java))

        worker = Thread {
            try {
                if (!VmManager.isRunning(c.id)) {
                    VmManager.start(applicationContext, c, store)
                }
            } catch (e: Exception) {
                runOnUiThread { fail(e.message ?: e.toString()) }
                return@Thread
            }
            connectAndRun()
        }.also { it.start() }
    }

    private fun connectAndRun() {
        val c0 = cfg
        val maxAttempts = if (c0 == null) 20 else 120
        runOnUiThread {
            if (c0 != null) setStatus(getString(R.string.connecting))
        }
        var attempts = 0
        while (!leaving) {
            if (c0 != null && !VmManager.isRunning(c0.id)) {
                val log = VmManager.tail(c0.id)
                runOnUiThread { fail("QEMU stopped unexpectedly.\n\n$log") }
                return
            }
            val c = VncClient("127.0.0.1", port)
            c.listener = this
            try {
                c.handshake()
            } catch (e: Exception) {
                c.close()
                attempts++
                if (attempts > maxAttempts) {
                    val msg = if (c0 == null) {
                        "Could not connect to 127.0.0.1:$port.\n\n" +
                            "Make sure QEMU is running in Termux with  -vnc 127.0.0.1:${port - 5900}  " +
                            "and that you used the same display number here."
                    } else {
                        "Could not connect to the VM display.\n\n${VmManager.tail(c0.id)}"
                    }
                    runOnUiThread { fail(msg) }
                    return
                }
                try {
                    Thread.sleep(1000)
                } catch (_: InterruptedException) {
                    return
                }
                continue
            }
            client = c
            runOnUiThread {
                view.attach(c)
                status.visibility = View.GONE
                view.requestFocus()
            }
            c.runLoop()
            return
        }
    }

    override fun onFrame() {
        view.postInvalidate()
    }

    override fun onClosed(reason: String) {
        runOnUiThread {
            if (leaving) return@runOnUiThread
            val c = cfg
            setStatus(
                when {
                    c == null -> "Disconnected from QEMU ($reason).\nGo back and connect again."
                    VmManager.isRunning(c.id) -> "Display disconnected ($reason).\nGo back and open the VM again."
                    else -> "The virtual machine has stopped."
                }
            )
        }
    }

    private fun setStatus(text: String) {
        status.text = text
        status.visibility = View.VISIBLE
    }

    private fun fail(message: String) {
        if (isFinishing) return
        if (cfg != null && VmManager.runningCount() == 0) {
            stopService(Intent(this, VmService::class.java))
        }
        AlertDialog.Builder(this)
            .setTitle("Could not connect")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun confirmPowerOff() {
        val c = cfg ?: return
        AlertDialog.Builder(this)
            .setTitle("Power off \"${c.name}\"?")
            .setMessage("This is like pulling the plug. Unsaved data inside the VM may be lost.")
            .setPositiveButton("Power off") { _, _ ->
                VmManager.stop(c.id)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        leaving = true
        client?.close()
        worker?.interrupt()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ID = "vm_id"
        const val EXTRA_PORT = "vnc_port"
    }
}
