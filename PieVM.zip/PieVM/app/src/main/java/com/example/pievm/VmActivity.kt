package com.example.pievm

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Shows one running VM: starts QEMU (if needed), connects over VNC and forwards input. */
class VmActivity : AppCompatActivity(), VncClient.Listener {

    private lateinit var store: VmStore
    private lateinit var cfg: VmConfig
    private lateinit var view: VncView
    private lateinit var status: TextView

    @Volatile
    private var client: VncClient? = null

    @Volatile
    private var leaving = false
    private var worker: Thread? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vm)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        store = VmStore(this)
        val id = intent.getStringExtra(EXTRA_ID)
        val found = id?.let { store.get(it) }
        if (found == null) {
            finish()
            return
        }
        cfg = found

        view = findViewById(R.id.vnc)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.btnBack).setOnClickListener { view.sendKey(VncView.KEYSYM_ESCAPE) }
        findViewById<Button>(R.id.btnHome).setOnClickListener { view.sendKey(VncView.KEYSYM_SUPER_L) }
        findViewById<Button>(R.id.btnKeys).setOnClickListener {
            view.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { confirmPowerOff() }

        startVm()
    }

    private fun startVm() {
        setStatus(getString(R.string.starting))
        ContextCompat.startForegroundService(this, Intent(this, VmService::class.java))

        worker = Thread {
            try {
                if (!VmManager.isRunning(cfg.id)) {
                    VmManager.start(applicationContext, cfg, store)
                }
            } catch (e: Exception) {
                runOnUiThread { fail(e.message ?: e.toString()) }
                return@Thread
            }
            connectAndRun()
        }.also { it.start() }
    }

    private fun connectAndRun() {
        runOnUiThread { setStatus(getString(R.string.connecting)) }
        var attempts = 0
        while (!leaving) {
            if (!VmManager.isRunning(cfg.id)) {
                val log = VmManager.tail(cfg.id)
                runOnUiThread { fail("QEMU stopped unexpectedly.\n\n$log") }
                return
            }
            val c = VncClient("127.0.0.1", cfg.vncPort)
            c.listener = this
            try {
                c.handshake()
            } catch (e: Exception) {
                c.close()
                attempts++
                if (attempts > 120) {
                    runOnUiThread { fail("Could not connect to the VM display.\n\n${VmManager.tail(cfg.id)}") }
                    return
                }
                try {
                    Thread.sleep(1000)
                } catch (_: InterruptedException) {
                    return
                }
                continue
            }
            client = c
            runOnUiThread {
                view.attach(c)
                status.visibility = View.GONE
                view.requestFocus()
            }
            c.runLoop()
            return
        }
    }

    override fun onFrame() {
        view.postInvalidate()
    }

    override fun onClosed(reason: String) {
        runOnUiThread {
            if (leaving) return@runOnUiThread
            val running = VmManager.isRunning(cfg.id)
            setStatus(
                if (running) "Display disconnected ($reason).\nGo back and open the VM again."
                else "The virtual machine has stopped."
            )
        }
    }

    private fun setStatus(text: String) {
        status.text = text
        status.visibility = View.VISIBLE
    }

    private fun fail(message: String) {
        if (isFinishing) return
        if (VmManager.runningCount() == 0) stopService(Intent(this, VmService::class.java))
        AlertDialog.Builder(this)
            .setTitle("Could not run the VM")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun confirmPowerOff() {
        AlertDialog.Builder(this)
            .setTitle("Power off \"${cfg.name}\"?")
            .setMessage("This is like pulling the plug. Unsaved data inside the VM may be lost.")
            .setPositiveButton("Power off") { _, _ ->
                VmManager.stop(cfg.id)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        leaving = true
        client?.close()
        worker?.interrupt()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ID = "vm_id"
    }
}
