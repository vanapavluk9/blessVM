package com.example.pievm

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

// Installs 64-bit QEMU if the phone supports it, otherwise the 32-bit one (qemu-system-i386)
private const val TERMUX_INSTALL =
    "pkg update -y && (pkg install -y qemu-system-x86-64-headless || " +
        "pkg install -y qemu-system-i386-headless) && pkg install -y qemu-utils && " +
        "termux-setup-storage && mkdir -p ~/vm && qemu-img create -f qcow2 ~/vm/disk.qcow2 16G"

// 64-bit QEMU -> android-x86_64-9.0-r2.iso ; 32-bit QEMU -> android-x86-9.0-r2.iso
private const val TERMUX_RUN =
    "termux-wake-lock; cd ~/vm; " +
        "if command -v qemu-system-x86_64 >/dev/null; then Q=qemu-system-x86_64; " +
        "ISO=\$(ls ~/storage/downloads/android-x86_64*.iso | head -n1); " +
        "else Q=qemu-system-i386; ISO=\$(ls ~/storage/downloads/android-x86-9*.iso | head -n1); fi; " +
        "echo \"\$Q \$ISO\"; " +
        "\$Q -machine pc -cpu max -accel tcg -m 2048 -smp 2 " +
        "-drive file=disk.qcow2,format=qcow2,if=virtio -cdrom \"\$ISO\" -boot d " +
        "-vga std -usb -device usb-tablet " +
        "-netdev user,id=n0,hostfwd=tcp:127.0.0.1:15555-:5555 -device e1000,netdev=n0 " +
        "-display none -vnc 127.0.0.1:1"

class MainActivity : AppCompatActivity() {

    private lateinit var store: VmStore
    private lateinit var adapter: VmAdapter
    private lateinit var listView: ListView
    private lateinit var emptyView: TextView

    private var pendingIso: Uri? = null
    private var isoLabel: TextView? = null

    private val pickIso = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingIso = uri
            isoLabel?.text = displayName(uri)
        }
    }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* optional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = VmStore(this)

        listView = findViewById(R.id.list)
        emptyView = findViewById(R.id.empty)
        adapter = VmAdapter()
        listView.adapter = adapter
        findViewById<Button>(R.id.btnNew).setOnClickListener { showNewVmDialog() }
        findViewById<Button>(R.id.btnGuide).setOnClickListener { showTermuxGuide() }
        findViewById<Button>(R.id.btnTermux).setOnClickListener { showTermuxConnect() }

        if (!VmManager.hasEngine(this)) {
            findViewById<View>(R.id.banner).visibility = View.VISIBLE
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        adapter.items = store.all()
        adapter.notifyDataSetChanged()
        val empty = adapter.items.isEmpty()
        emptyView.visibility = if (empty) View.VISIBLE else View.GONE
        listView.visibility = if (empty) View.GONE else View.VISIBLE
    }

    private fun copyToClipboard(label: String, text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "Скопировано. Вставьте в Termux (долгое нажатие → Paste).", Toast.LENGTH_LONG).show()
    }

    private fun showTermuxGuide() {
        val msg = """
            Как запустить Android 9 через Termux:

            1. Установите Termux из F-Droid (версия из Google Play устарела).
            2. Скачайте Android-x86 9.0 ISO в папку «Загрузки»: android-x86_64-9.0-r2.iso (64-бит) и, на всякий случай, android-x86-9.0-r2.iso (32-бит). Команда сама выберет нужный: на 32-битных телефонах Termux ставит только qemu-system-i386, ему нужен 32-битный образ.
            3. Нажмите «Копировать 1», вставьте в Termux и нажмите Enter. Разрешите доступ к памяти, когда спросит. Это установка QEMU и создание диска.
            4. Нажмите «Копировать 2», вставьте в Termux и Enter. Это запуск виртуальной машины.
            5. Вернитесь сюда, нажмите «Connect to QEMU in Termux» (номер экрана 1).
            6. В меню загрузки выберите Installation, установите Android на диск (ext4, bootable).
            7. После установки остановите QEMU в Termux (Ctrl+C) и запускайте уже без ISO: в команде 2 уберите часть «-cdrom» вместе с путём к ISO и «-boot d».

            Если имя пакета не найдено, выполните в Termux: pkg search qemu
        """.trimIndent()
        AlertDialog.Builder(this)
            .setTitle("Termux guide")
            .setMessage(msg)
            .setPositiveButton("Копировать 1") { _, _ -> copyToClipboard("install", TERMUX_INSTALL) }
            .setNeutralButton("Копировать 2") { _, _ -> copyToClipboard("run", TERMUX_RUN) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showTermuxConnect() {
        val et = EditText(this).apply {
            hint = "Display number (QEMU -vnc 127.0.0.1:N)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("1")
        }
        AlertDialog.Builder(this)
            .setTitle("Connect to QEMU in Termux")
            .setMessage("QEMU must already be running in Termux. VNC port = 5900 + display number.")
            .setView(et)
            .setPositiveButton("Connect") { _, _ ->
                val n = et.text.toString().toIntOrNull()?.coerceIn(0, 99) ?: 1
                startActivity(
                    Intent(this, VmActivity::class.java).putExtra(VmActivity.EXTRA_PORT, 5900 + n)
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRamDialog(cfg: VmConfig) {
        if (VmManager.isRunning(this, cfg.id)) {
            Toast.makeText(this, "Power off the VM first", Toast.LENGTH_SHORT).show()
            return
        }
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(cfg.ramMb.toString())
        }
        AlertDialog.Builder(this)
            .setTitle("RAM for \"${cfg.name}\" (MB)")
            .setMessage("On a 32-bit phone about 512 MB works best. If the VM fails with \"Out of memory\", lower this value.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                cfg.ramMb = (et.text.toString().toIntOrNull() ?: cfg.ramMb).coerceIn(256, 8192)
                store.update(cfg)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showNewVmDialog() {
        pendingIso = null
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_new_vm, null)
        val etName = v.findViewById<EditText>(R.id.etName)
        val etRam = v.findViewById<EditText>(R.id.etRam)
        val etCpus = v.findViewById<EditText>(R.id.etCpus)
        val etDisk = v.findViewById<EditText>(R.id.etDisk)
        isoLabel = v.findViewById(R.id.tvIso)
        v.findViewById<Button>(R.id.btnIso).setOnClickListener {
            pickIso.launch(arrayOf("*/*"))
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.new_vm)
            .setView(v)
            .setPositiveButton("Create", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = etName.text.toString().trim()
                val ram = etRam.text.toString().toIntOrNull()?.coerceIn(256, 8192) ?: 512
                val cpus = etCpus.text.toString().toIntOrNull()?.coerceIn(1, 8) ?: 2
                val disk = etDisk.text.toString().toIntOrNull()?.coerceIn(4, 128) ?: 16
                val iso = pendingIso
                when {
                    name.isEmpty() -> etName.error = "Enter a name"
                    iso == null -> Toast.makeText(this, "Choose the Android-x86 9.0 ISO first", Toast.LENGTH_LONG).show()
                    else -> {
                        dialog.dismiss()
                        createVm(name, ram, cpus, disk, iso)
                    }
                }
            }
        }
        dialog.show()
    }

    private fun createVm(name: String, ram: Int, cpus: Int, disk: Int, iso: Uri) {
        val cfg = store.create(name, ram, cpus, disk, hasIso = true)
        val progress = AlertDialog.Builder(this)
            .setTitle("Copying ISO…")
            .setMessage("This can take a minute for a large file.")
            .setView(ProgressBar(this).apply { isIndeterminate = true; setPadding(0, 24, 0, 24) })
            .setCancelable(false)
            .show()

        Thread {
            var ok = true
            try {
                contentResolver.openInputStream(iso)!!.use { input ->
                    store.isoFile(cfg.id).outputStream().use { input.copyTo(it) }
                }
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                progress.dismiss()
                if (!ok) {
                    store.delete(cfg.id)
                    Toast.makeText(this, "Could not copy the ISO file", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }.start()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "ISO selected"
    }

    private inner class VmAdapter : BaseAdapter() {
        var items: List<VmConfig> = emptyList()

        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = convertView ?: LayoutInflater.from(parent.context).inflate(R.layout.item_vm, parent, false)
            val cfg = items[position]
            val running = VmManager.isRunning(this@MainActivity, cfg.id)

            row.setOnLongClickListener {
                showRamDialog(cfg)
                true
            }
            row.findViewById<TextView>(R.id.vmName).text = cfg.name
            row.findViewById<TextView>(R.id.vmInfo).text =
                "Android 9.0 • ${cfg.ramMb} MB RAM • ${cfg.cpus} CPU • ${cfg.diskGb} GB" +
                    (if (running) " • running" else "") +
                    (if (!cfg.installed) " • not installed yet" else "") +
                    "\n(long-press to change RAM)"

            row.findViewById<Button>(R.id.btnStart).apply {
                setText(if (running) R.string.open else R.string.start)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, VmActivity::class.java).putExtra(VmActivity.EXTRA_ID, cfg.id))
                }
            }

            row.findViewById<Button>(R.id.btnDetach).apply {
                visibility = if (cfg.installed) View.GONE else View.VISIBLE
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Mark as installed?")
                        .setMessage(
                            "Do this after Android has been installed to the virtual disk inside the VM. " +
                                "The ISO will no longer be attached, so the VM boots from the disk."
                        )
                        .setPositiveButton("Yes") { _, _ ->
                            cfg.installed = true
                            store.update(cfg)
                            store.isoFile(cfg.id).delete()
                            refresh()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }

            row.findViewById<Button>(R.id.btnDelete).setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Delete \"${cfg.name}\"?")
                    .setMessage("The virtual disk and everything inside the VM will be removed.")
                    .setPositiveButton("Delete") { _, _ ->
                        store.delete(cfg.id)
                        refresh()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            return row
        }
    }
}
