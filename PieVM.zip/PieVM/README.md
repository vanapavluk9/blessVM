# Pie VM — Android 9.0 virtual machine app

Runs an **Android-x86 9.0 (Pie)** virtual machine inside an Android app, using QEMU.
Host phone: **Android 7.0 – 15** (minSdk 24, targetSdk 34). Guest: **Android 9.0 Pie**.

Because the guest is a full Android, every app you install in it is isolated from your real phone.
That is the "app sandbox" part: apps live inside the VM, not on the host.

## What is in this project

| File | What it does |
| --- | --- |
| `MainActivity` | List of VMs, create / delete, "mark installed" |
| `VmActivity` | Shows the VM screen, Back / Home / Keyboard / Power-off buttons |
| `VmManager` | Starts and stops the QEMU process |
| `VmService` | Foreground service so the VM keeps running in the background |
| `VncClient` / `VncView` | Draws the guest screen, sends touch and keyboard input |

## What you must add (not included, too large / licensed separately)

1. **QEMU engine** — a `qemu-system-x86_64` build for Android, saved as
   `app/src/main/jniLibs/arm64-v8a/libqemu.so` (and/or `x86_64/libqemu.so`).
   A statically linked build is easiest. Extra shared libraries go in the same folder as `lib<name>.so`.
2. **QEMU firmware files** (`bios-256k.bin`, `vgabios-stdvga.bin`, …) in
   `app/src/main/assets/qemu-share/`.
3. **Android-x86 9.0 ISO** (e.g. `android-x86_64-9.0-r2.iso`, from android-x86.org). You pick it inside the app.

## Build

1. Open this folder in **Android Studio** (Ladybug or newer) and let Gradle sync.
2. Add the files above, then **Build > Build APK(s)**.
3. Install the APK on the phone.

## First use

1. Tap **New virtual machine**, choose the ISO, create it, tap **Start**.
2. In the Android-x86 boot menu choose **Installation**, create a partition on the virtual disk
   (type: ext4, bootable), install, and skip GRUB if asked.
3. Power off the VM, tap **Mark installed** in the list, then **Start** again to boot from the disk.

## Controls

- One finger: mouse (tap = click, drag = drag). Two-finger tap: right click.
- **Back** sends Esc, **Home** sends the Super key (Android-x86 maps both).
- **Keyboard** opens the phone's keyboard and types into the guest.

## Good to know

- Phones have no hardware acceleration available to apps, so QEMU runs in software emulation (TCG).
  Expect slow boot (several minutes) and sluggish apps. Use 2 GB+ RAM and 2+ cores.
- The VM display is only reachable from the phone itself (VNC on 127.0.0.1).
- Each VM forwards a host port to the guest's adb port (`127.0.0.1:15555 + n`).
- Everything (disk, ISO) is stored in the app's private storage and removed on uninstall.
- If QEMU fails to start, the error dialog shows its last output.
