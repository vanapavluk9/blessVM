# Pie VM — Android 9.0 virtual machine app

Runs an **Android-x86 9.0 (Pie)** virtual machine inside an Android app, using QEMU.
Host phone: **Android 7.0 – 15** (minSdk 24, targetSdk 34). Guest: **Android 9.0 Pie**.

Because the guest is a full Android, every app you install in it is isolated from your real phone.
That is the "app sandbox" part: apps live inside the VM, not on the host.

## What is in this project

| File | What it does |
| --- | --- |
| `MainActivity` | List of VMs, create / delete, "mark installed" |
| `VmActivity` | Shows the VM screen, Back / Home / Keyboard / Power-off buttons |
| `VmManager` | Starts and stops the QEMU process |
| `VmService` | Foreground service so the VM keeps running in the background |
| `VncClient` / `VncView` | Draws the guest screen, sends touch and keyboard input |

## Two ways to run the VM

- **Built-in mode:** the app runs QEMU itself (32-bit ARM build of QEMU 5.1 from Limbo,
  in `app/src/main/jniLibs/armeabi-v7a`). QEMU runs in a separate process (`:vm`) and the
  app shows its screen over VNC on 127.0.0.1. Needs a 32-bit-capable ARM phone.
- **Termux mode:** run QEMU in Termux and use this app as the screen
  (**Termux setup guide** -> **Connect to QEMU in Termux**).

BIOS / VGA ROM / keymaps are added by the GitHub build. You only need the
**Android-x86 9.0 ISO** (pick it inside the app).

## Build

1. Easiest: use the GitHub Actions build (`.github/workflows/build.yml`).
   Or open this folder in **Android Studio** and copy QEMU's `bios-256k.bin`, `vgabios-stdvga.bin`,
   `kvmvapic.bin`, `linuxboot_dma.bin` and the `keymaps/` folder into `app/src/main/assets/qemu-share/`.
2. **Build > Build APK(s)**.
3. Install the APK on the phone.

## First use

1. Tap **New virtual machine**, choose the ISO, create it, tap **Start**.
2. In the Android-x86 boot menu choose **Installation**, create a partition on the virtual disk
   (type: ext4, bootable), install, and skip GRUB if asked.
3. Power off the VM, tap **Mark installed** in the list, then **Start** again to boot from the disk.

## Controls

- One finger: mouse (tap = click, drag = drag). Two-finger tap: right click.
- **Back** sends Esc, **Home** sends the Super key (Android-x86 maps both).
- **Keyboard** opens the phone's keyboard and types into the guest.

## Good to know

- Phones have no hardware acceleration available to apps, so QEMU runs in software emulation (TCG).
  Expect slow boot (several minutes) and sluggish apps. Use 2 GB+ RAM and 2+ cores.
- The VM display is only reachable from the phone itself (VNC on 127.0.0.1).
- Each VM forwards a host port to the guest's adb port (`127.0.0.1:15555 + n`).
- Everything (disk, ISO) is stored in the app's private storage and removed on uninstall.
- If QEMU fails to start, the error dialog shows its last output.
